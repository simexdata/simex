import en from "./locales/en.json";
import bg from "./locales/bg.json";

export const languages = { en, bg };
export const defaultLang = "en";
